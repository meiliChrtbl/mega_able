<?php 
    include "includes/config.php";
    if(isset($_GET['hapus'])){
        $Kabkode = $_GET["hapus"];
        mysqli_query($connection, "DELETE FROM kabupaten
        WHERE kabupatenKODE = '$Kabkode'");
        echo "<script>alert('DATA BERHASIL DIHAPUS');
            document.location='kabupaten.php'</script>";
    }
?>