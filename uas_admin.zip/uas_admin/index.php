<!DOCTYPE html>

<?php
    ob_start();
    session_start();
    if(!isset($_SESSION['emailuser'])){
        header("location:auth-normal-sign-in.php");
    }
?>

<head>
    <title>Wisata</title>
</head>

<?php include  "includes/config.php"; ?>

<body>
    <?php include "header.php"; ?>
            
</body>
<?php
    mysqli_close($connection);
    ob_end_flush();
?>
</html>