<!DOCTYPE html>
<?php
    ob_start();
    session_start();
    if(!isset($_SESSION['emailuser'])){
        header("location:auth-normal-sign-in.php");
    }
?>
<?php

include "includes/config.php";

if(isset($_POST['Simpan'])) {
    $beritakode = $_POST['inputKode'];
    $judul = $_POST['inputjudul'];
    $inti = $_POST['inti'];
    $penulis = $_POST['penulis'];
    $penerbit = $_POST['penerbit'];
    $tanggal = $_POST['tanggal'];
    $kodedestinasi = $_POST['destinasi'];

    mysqli_query($connection, "INSERT INTO berita VALUES ('$beritakode', '$judul', '$inti', '$penulis', '$penerbit', '$tanggal', '$kodedestinasi')");
    header("location:berita.php");
}  

$datadestinasi2 = mysqli_query($connection, "SELECT * FROM destinasi");

?>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
</head>
<body>

<?php include "header.php"; ?>
<div class="row">


<div class="col-sm-8">
<div class="row">

        <div class="col-sm-8">
            <div class="jumbotron jumbotron-fluid">
                <div class="container">
                    <h1 class="display-4">Input Berita</h1>
                </div>
            </div><!--penutup jumbtron-->
  <form method = "POST">
  <div class="form-group row">
    <label for="kodehotel" class="col-sm-2 col-form-label">Kode</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="kodehotel" name="inputKode"
      placeholder="Kode berita" maxlength="4">
    </div>
  </div>

  <div class="form-group row">
    <label for="judul" class="col-sm-2 col-form-label">Judul Berita</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="judul" name="inputjudul"
      placeholder="Judul berita">
    </div>
  </div>

  <div class="form-group row">
    <label for="beritainti" class="col-sm-2 col-form-label">Berita Inti</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="beritainti" name="inti"
      placeholder="Inti berita">
    </div> 
  </div>

  <div class="form-group row">
    <label for="penulis" class="col-sm-2 col-form-label">Penulis</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="penulis" name="penulis"
      placeholder="Penulis Berita">
    </div>
  </div>

  <div class="form-group row">
    <label for="penerbit" class="col-sm-2 col-form-label">Penerbit</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="penerbit" name="penerbit"
      placeholder="Penerbit berita">
    </div>
  </div>

  <div class="form-group row">
    <label for="date" class="col-sm-2 col-form-label">Penerbit</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="date" name="tanggal"
      placeholder="Tanggal terbit">
    </div>
  </div>

  <div class="form-group row">
    <label for="kodedestinasi" class="col-sm-2 col-form-label">Kode Destinasi</label>
    <div class="col-sm-10">
      <select class="form-control" id="kodedestinasi" name="destinasi">
        
          <?php while($row = mysqli_fetch_array($datadestinasi2)) 
          { ?>
            <option value="<?php echo $row["destinasiID"]?>">
              <?php echo $row["destinasiID"] ?>
              <?php echo $row["destinasinama"] ?>
          </option>
        <?php } ?>
          </div>
      </select>
    </div>
  </div>

  <div class="form-group row">
    <div class="col-sm-2"></div>
    <div class="col-sm-8">
    <button type="submit" class="btn btn-primary" name="Simpan" value="Simpan">Simpan </button>
    <button type="reset" class="btn btn-secondary" value="Batal" name="Batal">Batal</button>
    </div>
  </div>

</form>
</div>


</div> <!--penutup row-->

<div class="row">
        
        <div class="col-sm-8">
        <div class="card borderless-card">
              <div class="card-block inverse-breadcrumb">
                <div class="breadcrumb-header">
                    <h5>Daftar Berita Wisata</h5>
                       <span>Hasil Entri data pada Tabel Berita</span>
                 </div>
                </div>
        </div>
            <form method="POST">
                <div class="form-group row mb-2">
                    <label for="search" class="col-sm-3">Judul Berita</label>
                    <div class="col-sm-6">
                        <input type="text" name="search" class="form-control"
                        id="search" value="<?php if(isset($_POST['search'])) {echo $_POST['search'];} ?>" 
                        placeholder="Cari judul berita">
                    </div>
                    <input type="submit" name="kirim" class="col-sm-1 btn btn-primary"
                    value="Search">
                </div>
            </form>

            <div class="card">
            <div class="card-block table-border-style">
                <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode</th>
                        <th>Judul Berita</th>
                        <th>Berita Inti</th>
                        <th>Penulis </th>
                        <th>Penerbit</th>
                        <th>Tanggal Terbit</th>
                        <th>Kode Destinasi</th>
                        <th colspan="2" style="text-align:center">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php
                        if(isset($_POST["kirim"])) {
                            $search = $_POST['search'];
                            $query = mysqli_query($connection, "SELECT * FROM berita WHERE beritajudul LIKE '%".$search."%'
                            or beritainti LIKE '%".$search."%'
                            or penulis LIKE '%".$search."%'
                            or penerbit LIKE '%".$search."%'");
                        } else {
                            $query = mysqli_query($connection, "SELECT berita.*, destinasi.destinasiID, destinasi.destinasinama
                            FROM berita,destinasi WHERE
                            berita.destinasiID = destinasi.destinasiID");
                        }
                        $nomor = 1;
                        while($row = mysqli_fetch_array($query))
                        { ?>
                            <tr>
                                <td> <?php echo $nomor; ?></td>
                                <td> <?php echo $row['beritaID']; ?></td>
                                <td> <?php echo $row['beritajudul']; ?></td>
                                <td> <?php echo $row['beritainti']; ?></td>
                                <td> <?php echo $row['penulis']; ?></td>
                                <td> <?php echo $row['penerbit']; ?></td>
                                <td> <?php echo $row['tanggalterbit']; ?></td>
                                <td> <?php echo $row['destinasiID']; ?></td>
                                <td>
                                <a href="beritaedit.php?ubah=<?php echo $row["beritaID"]?>" class="btn btn-success btn-sm" title="EDIT">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                        <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                        <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                                    </svg>
                                </a>
                                </td>

                                <td>
                                <a href="beritahapus.php?hapus=<?php echo $row["beritaID"]?>" class="btn btn-danger btn-sm" title="DELETE">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                        <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                                        <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                                    </svg>
                                </a>
                                </td>
                            </tr>
                            <?php $nomor = $nomor +1;?>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
            </div>
            </div>
        </div>
        <div class="col-sm-1"></div>
    </div>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script type="text/javascript" >
  $(document).ready(function() {
    $('#kodedestinasi').select2({
    allowClear: true,
    placeholder: "Pilih Destinasi Wiata"
    });
  });
</script>

<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
  $( function() {
    $( "#date" ).datepicker({
      dateFormat: "yy-mm-dd"
    });
  } );
  </script>
</body>
<?php
    mysqli_close($connection);
    ob_end_flush();
?>
</html>